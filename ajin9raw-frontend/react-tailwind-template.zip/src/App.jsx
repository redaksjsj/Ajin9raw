export default function App() {
  return (
    <div className="text-center text-3xl text-blue-600 font-bold mt-20">
      ✅ React + Tailwind is ready!
    </div>
  )
}
